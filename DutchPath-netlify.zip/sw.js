const VERSION = "a941cfb554aa";
const PRECACHE = [["assets/index-BLcrXCrK.js","196548d6477b65ac"],["assets/index-DUdMhErL.css","2a046d16ba168f5c"],["content/index.json","afc4538039bc60fb"],["content/units/s1-u01.json","b5e10a75d9517bfa"],["content/units/s1-u02.json","c4fb6098358955d2"],["content/units/s1-u03.json","bd6a3979343ca0b1"],["content/units/s1-u04.json","f27a1b7b280830aa"],["content/units/s1-u05.json","ea596aee4c9ebd85"],["content/units/s1-u06.json","ada7a6fdf451b6df"],["content/units/s1-u07.json","2bc817b5d9378f29"],["content/units/s1-u08.json","b8c435f1f8bcd7d2"],["content/units/s1-u09.json","3d5cac4334f071fd"],["content/units/s1-u10.json","e5d3ab85313bdc5c"],["content/units/s1-u11.json","837dea1c93819edc"],["content/units/s1-u12.json","bf22dccaeacbfe82"],["content/units/s1-u13.json","74ce57451e137e00"],["content/units/s1-u14.json","a0f466f042469190"],["content/units/s1-u15.json","6f561101cb131d10"],["content/units/s2-u01.json","bd3adb9741fe85dd"],["content/units/s2-u02.json","29d8a3975621d6e8"],["content/units/s2-u03.json","e0d5b9ade0f7459b"],["content/units/s2-u04.json","2db5da77d23feb3c"],["content/units/s2-u05.json","bdd0df919b329f8a"],["content/units/s2-u06.json","7ce1f2f5cc377015"],["content/units/s2-u07.json","943723e48b3cee89"],["content/units/s2-u08.json","9fed2a22620df4de"],["content/units/s2-u09.json","a7c3d5a1bdfeb556"],["content/units/s2-u10.json","9416a0018b330748"],["content/units/s2-u11.json","bce81bc4d598a7a2"],["content/units/s2-u12.json","bc0c0418152165e7"],["content/units/s2-u13.json","1e08201a0fd16163"],["content/units/s2-u14.json","2fe3916f752c638a"],["content/units/s2-u15.json","2f22823d3faccad6"],["content/units/s3-u01.json","702fa4df5bd05c56"],["content/units/s3-u02.json","9abe08979933b569"],["content/units/s3-u03.json","3fa16820c879b6fb"],["content/units/s3-u04.json","dae62a9a383035ac"],["content/units/s3-u05.json","9ea9211a2c1c7845"],["content/units/s3-u06.json","631998e1adc4f9d8"],["content/units/s3-u07.json","da8e56cc8a11b1f6"],["content/units/s3-u08.json","4e19951f1080748a"],["content/units/s3-u09.json","44d54c137a4277b4"],["content/units/s3-u10.json","0aca15077b278e78"],["content/units/s3-u11.json","4531a62e91921ed0"],["content/units/s3-u12.json","881470a944d79947"],["content/units/s3-u13.json","99f778dd49b078bd"],["content/units/s3-u14.json","c3641acbc4eae65f"],["content/units/s3-u15.json","ac7761a8c84e85a2"],["content/units/s3-u16.json","29d06769ebb46ec2"],["content/units/s4-u01.json","469a5728cf4929e6"],["content/units/s4-u02.json","47d4fb54e5d00021"],["content/units/s4-u03.json","abd2a90273e7c63e"],["content/units/s4-u04.json","4cd57c2be346f249"],["content/units/s4-u05.json","63dfb272dcbbf55d"],["content/units/s4-u06.json","ad7e13f26b213726"],["content/units/s4-u07.json","ab7e6c36851f43fa"],["content/units/s4-u08.json","d9406e3ba0d241f5"],["content/units/s4-u09.json","986a20bbc0f2059a"],["content/units/s4-u10.json","4e789a4b62eb8b79"],["content/units/s4-u11.json","819e5e53817b0342"],["content/units/s4-u12.json","9e963dde936fc710"],["content/units/s4-u13.json","3789d0edb6c1e4be"],["content/units/s4-u14.json","37036e0759f062da"],["content/units/s4-u15.json","d641e00389ecf69b"],["content/units/s4-u16.json","7302868962f05a9d"],["content/units/s5-u01.json","723dfdf69e3484ea"],["content/units/s5-u02.json","f2792ba7d514aa8b"],["content/units/s5-u03.json","43bec33912f454f7"],["content/units/s5-u04.json","1bb8642fc2a4b17a"],["content/units/s5-u05.json","a6482da18b2c708d"],["content/units/s5-u06.json","2e01411cc4d1e458"],["content/units/s5-u07.json","d470979c0171f45d"],["content/units/s5-u08.json","df7fb5ad37c3cd73"],["content/units/s5-u09.json","c993cf0ebf7a2a8f"],["content/units/s5-u10.json","c18518fe907f6890"],["content/units/s5-u11.json","d68a16e317d2f77a"],["content/units/s5-u12.json","942c5540e114daec"],["content/units/s5-u13.json","1b5a0b65c051d484"],["content/units/s5-u14.json","c8ca3ce0e053c65e"],["content/units/s5-u15.json","65068d7525bff897"],["content/units/s5-u16.json","9f94ec962bde9d6d"],["content/units/s6-u01.json","3ae72ea4c1d718ce"],["content/units/s6-u02.json","024914f588983347"],["content/units/s6-u03.json","dcb8900c46f02c53"],["content/units/s6-u04.json","2a9a61b26a3c97d3"],["content/units/s6-u05.json","8313fefcb0fafa11"],["content/units/s6-u06.json","1bc20fee20c34419"],["content/units/s6-u07.json","c392216396200d50"],["content/units/s6-u08.json","486e87a15ada4a5f"],["content/units/s6-u09.json","93f92c71ec838fab"],["content/units/s6-u10.json","887cda2508a7d921"],["content/units/s6-u11.json","fb9cf37fbf8512a1"],["content/units/s6-u12.json","423b0edae034a2c1"],["content/units/s6-u13.json","a0abbb991c53c88b"],["content/units/s6-u14.json","047eb9d120591484"],["content/units/s6-u15.json","645f566617d8a997"],["content/units/s6-u16.json","8fb9513a733facf4"],["content/units/s7-u01.json","93178aae7f8f294c"],["content/units/s7-u02.json","8b42c1411144d038"],["content/units/s7-u03.json","b1f522c2849c764c"],["content/units/s7-u04.json","a9becb4204023f42"],["content/units/s7-u05.json","16d05db42a1a41db"],["content/units/s7-u06.json","01ecf6a594b387bd"],["content/units/s7-u07.json","9870c99c853db4af"],["content/units/s7-u08.json","3da502ce64667c5c"],["content/units/s7-u09.json","47a016eeef59b38d"],["content/units/s7-u10.json","8f739f0a3cec044d"],["content/units/s7-u11.json","8ce05cf0a679c226"],["content/units/s7-u12.json","baf7ca900a1c860c"],["content/units/s7-u13.json","ce7ce5c87c1aa2e9"],["content/units/s7-u14.json","451548bc4c0ded04"],["content/units/s7-u15.json","3e73d38c97a99f51"],["content/vocab/s1.json","a4744ca410f94f9d"],["content/vocab/s2.json","15c3d50a7273423d"],["content/vocab/s3.json","8f45aac002255bad"],["content/vocab/s4.json","bdd07da73f6345fb"],["content/vocab/s5.json","525d9b31672323b8"],["content/vocab/s6.json","aa02ec24d04051c2"],["content/vocab/s7.json","d6c489a8586b6f08"],["icons/apple-touch-icon.png","fce5e307f531e8d2"],["icons/icon-192.png","8c6abd612f033c3c"],["icons/icon-512.png","2eb109c8ff0e39ca"],["icons/icon-maskable-512.png","ba32b50219f15764"],["icons/icon.svg","1cafe9d7b661fc64"],["index.html","fab3e09fc6445008"],["manifest.webmanifest","7a1a8eafdf6c2faf"]];
/*
 * Service worker da DutchPath: guarda a aplicação e todas as lições no telemóvel,
 * para funcionar sem internet. Gerado por tools/build-sw.ts (a lista de ficheiros
 * PRECACHE e a VERSION são inseridas no topo durante o build).
 */
/* global PRECACHE, VERSION */
const PREFIX = 'dutchpath-';
const CACHE = PREFIX + VERSION;
const HASHES = 'sw-hashes.json';
const url = (path) => new URL(path, self.registration.scope).href;

async function broadcast(msg) {
  const all = await self.clients.matchAll({ includeUncontrolled: true });
  for (const c of all) c.postMessage(msg);
}

/** Hashes guardados por uma versão anterior: ficheiros iguais copiam-se sem os descarregar outra vez. */
async function previousCaches() {
  const names = (await caches.keys()).filter((n) => n.startsWith(PREFIX) && n !== CACHE);
  const out = [];
  for (const name of names) {
    const cache = await caches.open(name);
    const res = await cache.match(url(HASHES));
    if (res) out.push({ cache, hashes: await res.json().catch(() => ({})) });
  }
  return out;
}

async function precache() {
  const cache = await caches.open(CACHE);
  const old = await previousCaches();
  // Se uma instalação anterior foi interrompida, os ficheiros já guardados não se repetem.
  const doneRes = await cache.match(url(HASHES));
  const done = doneRes ? await doneRes.json().catch(() => ({})) : {};
  const total = PRECACHE.length;
  let count = 0;
  let lastSent = 0;
  const queue = [...PRECACHE];
  async function worker() {
    for (let item = queue.shift(); item; item = queue.shift()) {
      const [path, hash] = item;
      const key = url(path);
      if (done[path] !== hash) {
        let res;
        for (const o of old) {
          if (o.hashes[path] === hash) { res = await o.cache.match(key); if (res) break; }
        }
        if (!res) {
          res = await fetch(key, { cache: 'no-cache' });
          if (!res.ok) throw new Error(`${path}: ${res.status}`);
        }
        await cache.put(key, res);
      }
      count++;
      if (count - lastSent >= 10 || count === total) {
        lastSent = count;
        broadcast({ type: 'dutchpath-offline', state: 'saving', done: count, total });
      }
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  await cache.put(url(HASHES), new Response(JSON.stringify(Object.fromEntries(PRECACHE)), { headers: { 'Content-Type': 'application/json' } }));
}

self.addEventListener('install', (event) => {
  event.waitUntil(precache().then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith(PREFIX) && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
    await broadcast({ type: 'dutchpath-offline', state: 'ready', version: VERSION });
  })());
});

self.addEventListener('message', (event) => {
  if (event.data?.type !== 'dutchpath-status') return;
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const ready = !!(await cache.match(url(HASHES)));
    event.source?.postMessage({ type: 'dutchpath-offline', state: ready ? 'ready' : 'saving', version: VERSION });
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' || !req.url.startsWith(self.registration.scope)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    if (req.mode === 'navigate') {
      // A página abre sempre, com ou sem internet.
      return (await cache.match(url('index.html'))) ?? fetch(req);
    }
    const hit = await cache.match(req, { ignoreSearch: true, ignoreVary: true });
    if (hit) return hit;
    try {
      return await fetch(req);
    } catch (e) {
      return (await caches.match(req, { ignoreSearch: true, ignoreVary: true })) ?? Response.error();
    }
  })());
});

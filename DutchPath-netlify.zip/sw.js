const VERSION = "8821accbb02d";
const PRECACHE = [["assets/index-BW0_2pGu.css","af9e15e73aaaf28f"],["assets/index-C2kbC27H.js","00fa098ea786e346"],["content/index.json","3f077bf61a358284"],["content/units/s1-u01.json","6d249be75c277401"],["content/units/s1-u02.json","b067e37fc09f7bbe"],["content/units/s1-u03.json","d4ddd133e7d5645f"],["content/units/s1-u04.json","31a70345c83955b9"],["content/units/s1-u05.json","299253b0d1678cf3"],["content/units/s1-u06.json","4086ec2bbd94b2c7"],["content/units/s1-u07.json","0af287715ae55bbc"],["content/units/s1-u08.json","374e2c07b60dae93"],["content/units/s1-u09.json","3479f8438736e194"],["content/units/s1-u10.json","880c91bb48b899c6"],["content/units/s1-u11.json","8f5dbe224461c1e4"],["content/units/s1-u12.json","3e544c96ed0a67aa"],["content/units/s1-u13.json","9e0d85d00587f646"],["content/units/s1-u14.json","e156c182ecb6169c"],["content/units/s1-u15.json","e53bd4c96ccd718c"],["content/units/s2-u01.json","61789cbd461813b6"],["content/units/s2-u02.json","65b9494f9580696e"],["content/units/s2-u03.json","caa8807aed49252a"],["content/units/s2-u04.json","8fd8307bcaaff8c6"],["content/units/s2-u05.json","0f4a0bb3ce05f07f"],["content/units/s2-u06.json","6c305b3b8abe1768"],["content/units/s2-u07.json","8204d053bd46f5e5"],["content/units/s2-u08.json","54f5b5d8383b0246"],["content/units/s2-u09.json","f8efbaae8a7165d6"],["content/units/s2-u10.json","07c24c6ab10b62e3"],["content/units/s2-u11.json","684bc81ad852a695"],["content/units/s2-u12.json","d30db537e2007a98"],["content/units/s2-u13.json","1c3b911f5c9165c2"],["content/units/s2-u14.json","ff00886be60617df"],["content/units/s2-u15.json","e803129cd79085ed"],["content/units/s3-u01.json","13ed60bd81ab6e20"],["content/units/s3-u02.json","7cf44f7ec4d54dfd"],["content/units/s3-u03.json","8b91b640f090e2cb"],["content/units/s3-u04.json","48856551550a0a6b"],["content/units/s3-u05.json","8a2c39f4085a5e17"],["content/units/s3-u06.json","6c01b6e8db8a19f2"],["content/units/s3-u07.json","c3d21f2321048018"],["content/units/s3-u08.json","04bf2e9a6f8d67b3"],["content/units/s3-u09.json","24820346364dda3f"],["content/units/s3-u10.json","af0ab7762ad09bea"],["content/units/s3-u11.json","8db3ec396ba8f7a1"],["content/units/s3-u12.json","8a6c9ad9fd717f76"],["content/units/s3-u13.json","6768b8506e0c1d79"],["content/units/s3-u14.json","0e76110957e75353"],["content/units/s3-u15.json","299aae0813f3fb09"],["content/units/s3-u16.json","9ef597194222e348"],["content/units/s4-u01.json","7580a8d3add724a3"],["content/units/s4-u02.json","076e77f11ae39cf3"],["content/units/s4-u03.json","005f9bca9cfe2293"],["content/units/s4-u04.json","14457bc0748e3e59"],["content/units/s4-u05.json","c10af1f9af8cdf2c"],["content/units/s4-u06.json","6dc724c05025cf4a"],["content/units/s4-u07.json","74c0c50d9e611a1b"],["content/units/s4-u08.json","a0fdd8b614fc3b8c"],["content/units/s4-u09.json","2e02276b45fb8d63"],["content/units/s4-u10.json","bef2d64812cfbf10"],["content/units/s4-u11.json","e9b4bdfa1305e6ce"],["content/units/s4-u12.json","99b3bdaf00d27824"],["content/units/s4-u13.json","2d9d15c54a5c5199"],["content/units/s4-u14.json","b5c60944300da93b"],["content/units/s4-u15.json","4290aa4fde64d450"],["content/units/s4-u16.json","52c9863de0467028"],["content/units/s5-u01.json","f950a875784b72eb"],["content/units/s5-u02.json","26040bfa7d0579dc"],["content/units/s5-u03.json","b6ede22935c4d747"],["content/units/s5-u04.json","f907dac2e4cf7fa8"],["content/units/s5-u05.json","a8dd903c0acc83bd"],["content/units/s5-u06.json","26db4d2bffc93c7f"],["content/units/s5-u07.json","0d8ecc2da4c3526c"],["content/units/s5-u08.json","46a72adf15d7bbdf"],["content/units/s5-u09.json","70eff979e99ff6fe"],["content/units/s5-u10.json","571868789f2429a7"],["content/units/s5-u11.json","7dcc5714a25cd127"],["content/units/s5-u12.json","8c06e53e983f66cb"],["content/units/s5-u13.json","ec517ccf99748c23"],["content/units/s5-u14.json","b9cbd77958f8474a"],["content/units/s5-u15.json","8647c0b9ce7313d5"],["content/units/s5-u16.json","dd0d7ecad2846c0b"],["content/units/s6-u01.json","ef4808f6eddc6372"],["content/units/s6-u02.json","b182ba64459bd8a5"],["content/units/s6-u03.json","0c3771080c6ca61f"],["content/units/s6-u04.json","37e031a398289b77"],["content/units/s6-u05.json","25730829cd0f0e3d"],["content/units/s6-u06.json","14826a24e8d8f3ee"],["content/units/s6-u07.json","f4a25958c747a553"],["content/units/s6-u08.json","49b728b30897f697"],["content/units/s6-u09.json","9eceac711cbad448"],["content/units/s6-u10.json","ce7d0a80cd2bdcb6"],["content/units/s6-u11.json","0b13f017fa43624d"],["content/units/s6-u12.json","d1acc867bd5636a8"],["content/units/s6-u13.json","786c589ee3070ae4"],["content/units/s6-u14.json","0daec72e5488e700"],["content/units/s6-u15.json","eefd29629532c2c9"],["content/units/s6-u16.json","39fd988a4b6b1e7a"],["content/units/s7-u01.json","c7f89e63f83b7ff1"],["content/units/s7-u02.json","6fbae6f887972d03"],["content/units/s7-u03.json","861a2fc393d05259"],["content/units/s7-u04.json","17fcdda96759c2d3"],["content/units/s7-u05.json","bcc4b4cc757680a0"],["content/units/s7-u06.json","21b622a957e2caf2"],["content/units/s7-u07.json","5c7e679b84ec41c3"],["content/units/s7-u08.json","0da8d7cfca7126b0"],["content/units/s7-u09.json","54dfbe78d442fa8a"],["content/units/s7-u10.json","daeb0bfc08b978b0"],["content/units/s7-u11.json","3fb6fe3c4f521ecc"],["content/units/s7-u12.json","8deedd9856b87ec7"],["content/units/s7-u13.json","a3c5da675360c8a1"],["content/units/s7-u14.json","680281d9bb4068a7"],["content/units/s7-u15.json","1c87f0a77447c56f"],["content/vocab/s1.json","1469ae94cd1ed0b6"],["content/vocab/s2.json","5c62d1d7ab87253f"],["content/vocab/s3.json","9aff78264466cca4"],["content/vocab/s4.json","1a27bd0a10f1f64d"],["content/vocab/s5.json","72b8749de0b7b2e3"],["content/vocab/s6.json","3fd69e9295d1c852"],["content/vocab/s7.json","9ab028b7f9931651"],["icons/apple-touch-icon.png","0763d20a293de4cf"],["icons/icon-192.png","887db0325dee2302"],["icons/icon-512.png","3512ed81856ab31c"],["icons/icon-maskable-512.png","1bf5ed197853cc4d"],["icons/icon.svg","eb26e18194edb75f"],["./","c40c1ac783c48803"],["manifest.webmanifest","7a1a8eafdf6c2faf"]];
/*
 * Service worker da DutchPath: guarda a aplicação e todas as lições no telemóvel,
 * para funcionar sem internet. Gerado por tools/build-sw.ts (a lista de ficheiros
 * PRECACHE e a VERSION são inseridas no topo durante o build).
 */
/* global PRECACHE, VERSION */
const PREFIX = 'dutchpath-';
const CACHE = PREFIX + VERSION;
const HASHES = 'sw-hashes.json';
const url = (path) => new URL(path, self.registration.scope).href;

async function broadcast(msg) {
  const all = await self.clients.matchAll({ includeUncontrolled: true });
  for (const c of all) c.postMessage(msg);
}

/** Hashes guardados por uma versão anterior: ficheiros iguais copiam-se sem os descarregar outra vez. */
async function previousCaches() {
  const names = (await caches.keys()).filter((n) => n.startsWith(PREFIX) && n !== CACHE);
  const out = [];
  for (const name of names) {
    const cache = await caches.open(name);
    const res = await cache.match(url(HASHES));
    if (res) out.push({ cache, hashes: await res.json().catch(() => ({})) });
  }
  return out;
}

async function precache() {
  const cache = await caches.open(CACHE);
  const old = await previousCaches();
  // Se uma instalação anterior foi interrompida, os ficheiros já guardados não se repetem.
  const doneRes = await cache.match(url(HASHES));
  const done = doneRes ? await doneRes.json().catch(() => ({})) : {};
  const total = PRECACHE.length;
  let count = 0;
  let lastSent = 0;
  const queue = [...PRECACHE];
  async function worker() {
    for (let item = queue.shift(); item; item = queue.shift()) {
      const [path, hash] = item;
      const key = url(path);
      if (done[path] !== hash) {
        let res;
        for (const o of old) {
          if (o.hashes[path] === hash) { res = await o.cache.match(key); if (res) break; }
        }
        if (!res) {
          res = await fetch(key, { cache: 'no-cache' });
          if (!res.ok) throw new Error(`${path}: ${res.status}`);
          // Uma resposta que veio de um redirecionamento não pode servir uma página (Safari/Chrome recusam).
          if (res.redirected) res = new Response(await res.blob(), { status: res.status, statusText: res.statusText, headers: res.headers });
        }
        await cache.put(key, res);
      }
      count++;
      if (count - lastSent >= 10 || count === total) {
        lastSent = count;
        broadcast({ type: 'dutchpath-offline', state: 'saving', done: count, total });
      }
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  await cache.put(url(HASHES), new Response(JSON.stringify(Object.fromEntries(PRECACHE)), { headers: { 'Content-Type': 'application/json' } }));
}

self.addEventListener('install', (event) => {
  event.waitUntil(precache().then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith(PREFIX) && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
    await broadcast({ type: 'dutchpath-offline', state: 'ready', version: VERSION });
  })());
});

self.addEventListener('message', (event) => {
  if (event.data?.type !== 'dutchpath-status') return;
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const ready = !!(await cache.match(url(HASHES)));
    event.source?.postMessage({ type: 'dutchpath-offline', state: ready ? 'ready' : 'saving', version: VERSION });
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' || !req.url.startsWith(self.registration.scope)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    if (req.mode === 'navigate') {
      // A página abre sempre, com ou sem internet.
      return (await cache.match(url('./'), { ignoreSearch: true, ignoreVary: true })) ?? fetch(req);
    }
    const hit = await cache.match(req, { ignoreSearch: true, ignoreVary: true });
    if (hit) return hit;
    try {
      return await fetch(req);
    } catch (e) {
      return (await caches.match(req, { ignoreSearch: true, ignoreVary: true })) ?? Response.error();
    }
  })());
});

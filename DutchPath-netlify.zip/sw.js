const VERSION = "d6d1b59d7a81";
const PRECACHE = [["assets/index-QtIpd83e.css","9e34eaadb8965367"],["assets/index-gqyuPfVR.js","dee9b3fc41069ce8"],["content/index.json","d7dbd152fc871e98"],["content/units/s1-u01.json","0fa69e64d8623a3b"],["content/units/s1-u02.json","596c25e1989f36ba"],["content/units/s1-u03.json","1edcb0a4df4f7ac5"],["content/units/s1-u04.json","d95a2e74855d46ef"],["content/units/s1-u05.json","b90dbba52a6c645b"],["content/units/s1-u06.json","c8d37256ef7bdb42"],["content/units/s1-u07.json","8c7317bced750821"],["content/units/s1-u08.json","606199007cbeb8d5"],["content/units/s1-u09.json","832dff65c24600ca"],["content/units/s1-u10.json","50e5bce3179050f3"],["content/units/s1-u11.json","b40fb0e450c20c70"],["content/units/s1-u12.json","86e32afd95458b5d"],["content/units/s1-u13.json","ca816f97b1d572a2"],["content/units/s1-u14.json","e7228ef02f200173"],["content/units/s1-u15.json","edf4231bc1ccde43"],["content/units/s2-u01.json","ca66e451049ebe85"],["content/units/s2-u02.json","4a4a779d311d6801"],["content/units/s2-u03.json","589a2edb2289d4b3"],["content/units/s2-u04.json","73f5e7bd958c57fa"],["content/units/s2-u05.json","d554e311022ba554"],["content/units/s2-u06.json","c86e34ab09d04df3"],["content/units/s2-u07.json","5228c7bbd4291323"],["content/units/s2-u08.json","a16d8c811b05e39d"],["content/units/s2-u09.json","c4632b2d908303fe"],["content/units/s2-u10.json","07c24c6ab10b62e3"],["content/units/s2-u11.json","042c81f3f8682c23"],["content/units/s2-u12.json","956eea910ed2659b"],["content/units/s2-u13.json","de142dbfd0c4ca14"],["content/units/s2-u14.json","e61c6414d99fa00e"],["content/units/s2-u15.json","1c9b2bd3054744c6"],["content/units/s3-u01.json","0254896ec6ef6fee"],["content/units/s3-u02.json","b465b594a5645e5f"],["content/units/s3-u03.json","7459a487b6a1fd10"],["content/units/s3-u04.json","d51bf077f8d503ec"],["content/units/s3-u05.json","6d785c3c9d7a441e"],["content/units/s3-u06.json","ddf21ebf92288a66"],["content/units/s3-u07.json","7afabe850a58b844"],["content/units/s3-u08.json","fd4095fd1b76d38d"],["content/units/s3-u09.json","d1fa70ac1488406c"],["content/units/s3-u10.json","c903985570a2b45e"],["content/units/s3-u11.json","da798b43ca63a703"],["content/units/s3-u12.json","edf8403e39a950f2"],["content/units/s3-u13.json","b546fe3c486b42c2"],["content/units/s3-u14.json","e224b81f0e81ccf2"],["content/units/s3-u15.json","4844f266bfb7197d"],["content/units/s3-u16.json","875ddb98643880bd"],["content/units/s4-u01.json","5cb98e5b72209ad1"],["content/units/s4-u02.json","1910f150b20658d6"],["content/units/s4-u03.json","7e8b84c1c8339893"],["content/units/s4-u04.json","51efd809a7de6ff6"],["content/units/s4-u05.json","f1e9a793531081ac"],["content/units/s4-u06.json","0ce2800264e5c424"],["content/units/s4-u07.json","54852a54c1ae2701"],["content/units/s4-u08.json","7ce35aa29257de6e"],["content/units/s4-u09.json","2a9fcaba3e17f5cf"],["content/units/s4-u10.json","4577ed55884111d1"],["content/units/s4-u11.json","10682fca866b74d9"],["content/units/s4-u12.json","6f73dc5f13490044"],["content/units/s4-u13.json","f3e94934cd703947"],["content/units/s4-u14.json","64acb0b7ebf0608d"],["content/units/s4-u15.json","18f690b8259e0e4e"],["content/units/s4-u16.json","899a2a06042fa42c"],["content/units/s5-u01.json","acee35384187a9d4"],["content/units/s5-u02.json","18b779e5211c9758"],["content/units/s5-u03.json","49bd501d865fbf78"],["content/units/s5-u04.json","3d0d1ca551c4156f"],["content/units/s5-u05.json","fe0d04ee452e1f82"],["content/units/s5-u06.json","488ef6435800ebbf"],["content/units/s5-u07.json","4e84450f9f98881d"],["content/units/s5-u08.json","fd0b5f23684e81aa"],["content/units/s5-u09.json","d9aa5a76ae5649b9"],["content/units/s5-u10.json","b9070a1d006edb91"],["content/units/s5-u11.json","d5f981a20620a53c"],["content/units/s5-u12.json","cba73584869d5981"],["content/units/s5-u13.json","f24036e44c748b98"],["content/units/s5-u14.json","2a6da444361bfdfd"],["content/units/s5-u15.json","a6aba681c8130a73"],["content/units/s5-u16.json","2d57ce54610894cc"],["content/units/s6-u01.json","6d681d67fc6ebec5"],["content/units/s6-u02.json","a0126074085992a3"],["content/units/s6-u03.json","f880068cf1a9117c"],["content/units/s6-u04.json","680fd454d5cfe05d"],["content/units/s6-u05.json","5e63b5b86cca78b4"],["content/units/s6-u06.json","3052044488926f42"],["content/units/s6-u07.json","0f5001fa01fb2aa5"],["content/units/s6-u08.json","a67a4d3c9c27dca2"],["content/units/s6-u09.json","1b090710f7a754ca"],["content/units/s6-u10.json","0193b0ff99a3a492"],["content/units/s6-u11.json","4956928b1b5447c4"],["content/units/s6-u12.json","15de4444fe3ab355"],["content/units/s6-u13.json","5c9243552c0bd794"],["content/units/s6-u14.json","c42cb432f077d0b1"],["content/units/s6-u15.json","f5bf07764506c2d3"],["content/units/s6-u16.json","5f7f14cd1dd27d34"],["content/units/s7-u01.json","506d0496f6c27f85"],["content/units/s7-u02.json","c46deedaba10c18c"],["content/units/s7-u03.json","9f8129f725cf6977"],["content/units/s7-u04.json","08e1706b66e374aa"],["content/units/s7-u05.json","016cbf785232a4ea"],["content/units/s7-u06.json","fb0cbdcffd7ae4fe"],["content/units/s7-u07.json","f5cb57154b36cbfe"],["content/units/s7-u08.json","e3ad467386cc16ef"],["content/units/s7-u09.json","bcaae4b6c2838203"],["content/units/s7-u10.json","f6cd678a95fb9dff"],["content/units/s7-u11.json","a773962a1c72994c"],["content/units/s7-u12.json","7789bae850560067"],["content/units/s7-u13.json","82442d8dc203693c"],["content/units/s7-u14.json","0564b483685f1f00"],["content/units/s7-u15.json","ef7849a098af56d8"],["content/vocab/s1.json","a4744ca410f94f9d"],["content/vocab/s2.json","15c3d50a7273423d"],["content/vocab/s3.json","8f45aac002255bad"],["content/vocab/s4.json","bdd07da73f6345fb"],["content/vocab/s5.json","525d9b31672323b8"],["content/vocab/s6.json","aa02ec24d04051c2"],["content/vocab/s7.json","d6c489a8586b6f08"],["icons/apple-touch-icon.png","a08e6b66c567bf97"],["icons/icon-192.png","7ead1cf382d9e230"],["icons/icon-512.png","4244b893944020d7"],["icons/icon-maskable-512.png","98af6560221cfc4b"],["icons/icon.svg","578be8b7a8ef8e81"],["./","079d7184103deb01"],["manifest.webmanifest","7a1a8eafdf6c2faf"]];
/*
 * Service worker da DutchPath: guarda a aplicação e todas as lições no telemóvel,
 * para funcionar sem internet. Gerado por tools/build-sw.ts (a lista de ficheiros
 * PRECACHE e a VERSION são inseridas no topo durante o build).
 */
/* global PRECACHE, VERSION */
const PREFIX = 'dutchpath-';
const CACHE = PREFIX + VERSION;
const HASHES = 'sw-hashes.json';
const url = (path) => new URL(path, self.registration.scope).href;

async function broadcast(msg) {
  const all = await self.clients.matchAll({ includeUncontrolled: true });
  for (const c of all) c.postMessage(msg);
}

/** Hashes guardados por uma versão anterior: ficheiros iguais copiam-se sem os descarregar outra vez. */
async function previousCaches() {
  const names = (await caches.keys()).filter((n) => n.startsWith(PREFIX) && n !== CACHE);
  const out = [];
  for (const name of names) {
    const cache = await caches.open(name);
    const res = await cache.match(url(HASHES));
    if (res) out.push({ cache, hashes: await res.json().catch(() => ({})) });
  }
  return out;
}

async function precache() {
  const cache = await caches.open(CACHE);
  const old = await previousCaches();
  // Se uma instalação anterior foi interrompida, os ficheiros já guardados não se repetem.
  const doneRes = await cache.match(url(HASHES));
  const done = doneRes ? await doneRes.json().catch(() => ({})) : {};
  const total = PRECACHE.length;
  let count = 0;
  let lastSent = 0;
  const queue = [...PRECACHE];
  async function worker() {
    for (let item = queue.shift(); item; item = queue.shift()) {
      const [path, hash] = item;
      const key = url(path);
      if (done[path] !== hash) {
        let res;
        for (const o of old) {
          if (o.hashes[path] === hash) { res = await o.cache.match(key); if (res) break; }
        }
        if (!res) {
          res = await fetch(key, { cache: 'no-cache' });
          if (!res.ok) throw new Error(`${path}: ${res.status}`);
          // Uma resposta que veio de um redirecionamento não pode servir uma página (Safari/Chrome recusam).
          if (res.redirected) res = new Response(await res.blob(), { status: res.status, statusText: res.statusText, headers: res.headers });
        }
        await cache.put(key, res);
      }
      count++;
      if (count - lastSent >= 10 || count === total) {
        lastSent = count;
        broadcast({ type: 'dutchpath-offline', state: 'saving', done: count, total });
      }
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  await cache.put(url(HASHES), new Response(JSON.stringify(Object.fromEntries(PRECACHE)), { headers: { 'Content-Type': 'application/json' } }));
}

self.addEventListener('install', (event) => {
  event.waitUntil(precache().then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith(PREFIX) && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
    await broadcast({ type: 'dutchpath-offline', state: 'ready', version: VERSION });
  })());
});

self.addEventListener('message', (event) => {
  if (event.data?.type !== 'dutchpath-status') return;
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const ready = !!(await cache.match(url(HASHES)));
    event.source?.postMessage({ type: 'dutchpath-offline', state: ready ? 'ready' : 'saving', version: VERSION });
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' || !req.url.startsWith(self.registration.scope)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    if (req.mode === 'navigate') {
      // A página abre sempre, com ou sem internet.
      return (await cache.match(url('./'), { ignoreSearch: true, ignoreVary: true })) ?? fetch(req);
    }
    const hit = await cache.match(req, { ignoreSearch: true, ignoreVary: true });
    if (hit) return hit;
    try {
      return await fetch(req);
    } catch (e) {
      return (await caches.match(req, { ignoreSearch: true, ignoreVary: true })) ?? Response.error();
    }
  })());
});
